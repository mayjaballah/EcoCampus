<?php
define('GROQ_API_KEY', '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');
define('GROQ_MODEL', 'openai/gpt-oss-20b');

define('GMAIL_USERNAME','malekchuigui@gmail.com');
define('GMAIL_PASSWORD','kscv bghv kdmo eqte');
